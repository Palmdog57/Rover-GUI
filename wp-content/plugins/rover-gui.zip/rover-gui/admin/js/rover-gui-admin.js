(function( $ ) {
	'use strict';

	jQuery(function ($) { 
			//Code in here

	});



})( jQuery );
