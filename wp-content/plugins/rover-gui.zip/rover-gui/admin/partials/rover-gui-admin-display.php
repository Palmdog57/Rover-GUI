<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       www.cheesecakeproductions.com
 * @since      1.0.0
 *
 * @package    Rover_Gui
 * @subpackage Rover_Gui/admin/partials
 */
?>

<!-- 
<form method="post" name="add_admin_post_rover_gui" action="<?php echo admin_url() . 'admin-post.php' ?>" class="pluginform">
<?php
add_action( 'admin_post_nopriv_add_admin_post_rover_gui', 'prefix_admin_add_admin_post_rover_gui' );
?>
<input type="hidden" name="action" value="add_admin_post_rover_gui"/>


<input type="submit" value="submitbuttontext" name="add_admin_post_rover_gui_submit"/>
<?php
  wp_nonce_field('add_admin_post_rover_gui', 'add_admin_post_nonce');
?>
</form>
 -->
