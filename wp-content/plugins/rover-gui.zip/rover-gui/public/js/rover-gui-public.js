(function( $ ) {
	'use strict';
		
		jQuery(function ($) { 
      var socket = io.connect('http://127.0.0.1:8080');
      console.log('you are connected dont worry');


      socket.emit('dump', function(data){
        $('#dumpdiv').append('<pre>' + data + '</pre>');
      	console.log(data);
      });

      socket.emit('new_data', function(data){
        $('#dumpdiv').append('<pre>' + data + '</pre>');
      	
      	console.log(data);


      });
      
	/* Code to go here */
      
         var w = $(window).width();
         var h = $(window).height();
      $('#full-body').css("width" , w);
      $('#full-body').css("height" , h);
      
      var save_current = 1;
      window.rover_btns = rover_btns;
      function rover_btns(n){
        //consol.log('button number :' + n);
        if(n == save_current){
        
        }else{
        $("#rover-page-" + save_current).addClass('inactive');
        $("#rover-page-" + n).removeClass('inactive');
        $("#rover-page-" + n).addClass('active');
        }
        
        console.log(save_current + ':' + n);
        save_current = n;
        
      
      }



		});

})( jQuery );
