<div id="headercont" class="displaynone"><?php get_header(); ?></div>

	<main role="main">
		<!-- section -->
		<section>



		</section>
		<!-- /section -->
	</main>

<!--<div id="sidebarcont" class="displaynone"><?php //get_sidebar(); ?></div>-->

<div id="footercont" class="displaynone"><?php get_footer(); ?></div>
